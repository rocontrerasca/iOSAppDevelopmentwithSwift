//
//  Result.swift
//  SearchingBooks
//
//  Created by Developer 1 on 4/22/18.
//  Copyright © 2018 comDeveloper. All rights reserved.
//

import UIKit

class Result: UICollectionViewCell {
    
    @IBOutlet weak var imgCover: UIImageView!
    @IBOutlet weak var lblBookTitle: UILabel!
}
