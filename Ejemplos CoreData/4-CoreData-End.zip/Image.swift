//
//  Image.swift
//  PhotoFeed
//
//  Created by Mike Spears on 2016-01-10.
//  Copyright © 2016 YourOganisation. All rights reserved.
//

import Foundation
import CoreData


class Image: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
